# 清空 wins_log.txt
with open('wins_log.txt', 'w') as wins_file:
    wins_file.write('')

# 将 game_count.txt 的数字变成 0
with open('game_count.txt', 'w') as game_count_file:
    game_count_file.write('0')

# 将 game_count.txt 的数字变成 0
with open('MLPiteration.txt', 'w') as game_count_file:
    game_count_file.write('0')
