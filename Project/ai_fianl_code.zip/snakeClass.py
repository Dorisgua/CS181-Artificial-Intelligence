# Snake结构体
class Snake:
    def __init__(self, color, id, pos, dir, body, score, alive, agent):
        self.color = color
        self.id = id
        self.pos = pos
        self.dir = dir
        self.body = body
        self.score = score
        self.alive = alive
        self.agent = agent